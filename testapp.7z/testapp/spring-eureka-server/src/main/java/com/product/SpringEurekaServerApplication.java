package com.product;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class SpringEurekaServerApplication {
    
    public static final Log LOGGER = LogFactory.getLog(SpringEurekaServerApplication.class);
    
    public static void main(String[] args) {
        SpringApplication.run(SpringEurekaServerApplication.class, args);
        System.setProperty("https.proxyHost", "sysproxy.wal-mart.com");
        System.setProperty("https.proxyPort", "8080");
        LOGGER.info("::: Server started :::");
    }
}

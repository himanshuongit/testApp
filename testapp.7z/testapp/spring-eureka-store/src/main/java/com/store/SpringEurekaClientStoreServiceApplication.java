package com.store;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class SpringEurekaClientStoreServiceApplication {

    public static final Log LOGGER = LogFactory.getLog(SpringEurekaClientStoreServiceApplication.class);



    public static void main(String[] args) {
        SpringApplication.run(SpringEurekaClientStoreServiceApplication.class, args);
        System.setProperty("https.proxyHost", "sysproxy.wal-mart.com");
        System.setProperty("https.proxyPort", "8080");
        LOGGER.info("::: store app started :::");
    }
}

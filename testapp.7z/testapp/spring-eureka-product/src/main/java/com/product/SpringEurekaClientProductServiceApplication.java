package com.product;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class SpringEurekaClientProductServiceApplication {

    public static final Log LOGGER = LogFactory.getLog(SpringEurekaClientProductServiceApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(SpringEurekaClientProductServiceApplication.class, args);
        System.setProperty("https.proxyHost", "sysproxy.wal-mart.com");
        System.setProperty("https.proxyPort", "8080");
        LOGGER.info("::: product app started :::");
    }
}

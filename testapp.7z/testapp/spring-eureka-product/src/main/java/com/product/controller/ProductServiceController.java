package com.product.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.product.model.Product;

@RestController
public class ProductServiceController {

    private static Map<String, List<Product>> ProductList = new HashMap<String, List<Product>>();

    static {
        ProductList = new HashMap<String, List<Product>>();

        List<Product> lst = new ArrayList<Product>();
        Product pl = new Product("ID001", "Computers");
        lst.add(pl);
        pl = new Product("ID002", "Laptops");
        lst.add(pl);

        ProductList.put("ABC", lst);

        lst = new ArrayList<Product>();
        pl = new Product("ID003", "AC");
        lst.add(pl);
        pl = new Product("ID004", "Fans");
        lst.add(pl);
        ProductList.put("XYZ", lst);
    }

    @RequestMapping(value = "/api/v1/service/{storeName}", method = RequestMethod.GET)
    public List<Product> getProducts(@PathVariable String storeName) {
        System.out.println("Getting Product details for " + storeName);

        List<Product> list = ProductList.get(storeName);
        if (list == null) {
            list = new ArrayList<Product>();
            Product pl = new Product("Not Found", "N/A");
            list.add(pl);
        }
        return list;
    }
}
